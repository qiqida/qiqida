---
title: Please Remove This Post
date: 2022-11-21 9:42:38 +0800
categories: [Test, Placeholder]
tags: [test]     # TAG names should always be lowercase
---

## 请移除该帖子

该帖子仅仅只是为了保证 `_posts` 文件夹不被 git 忽略而存在的。
