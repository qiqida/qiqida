---
title: Pretty Slugs
category: 💎
---

Post with 💎 category.
